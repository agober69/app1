package mypp1.pkg1;

import java.io.File;

import android.app.Activity;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputFilter;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.MediaController;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

public class App1Activity extends Activity {
	private static final String DEBUG_TAG = "app1";
	private MediaPlayer mp;
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		Log.i(DEBUG_TAG,"APP1 log message before toast");
		System.out.println("before toast");
		Toast.makeText(this,"App1 starting",Toast.LENGTH_LONG).show();
		System.out.println("After toast");
		Log.i(DEBUG_TAG,"APP1 log message after toast");


		final EditText textfltrd= (EditText)findViewById(R.id.edittextview02);
		textfltrd.setFilters(new InputFilter[]
		                                     {
				new InputFilter.AllCaps(),
				new InputFilter.LengthFilter(12)
		                                     });

		final Spinner spnr = (Spinner) findViewById(R.id.spinner01);

		spnr.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() 
		{
			public void onItemSelected(AdapterView<?> parent,
					View v, int position, long id)
			{
				TextView tv = (TextView) spnr.getSelectedView();
				CharSequence selt = tv.getText();
				final TextView spr = (TextView) findViewById(R.id.textview03);
				spr.setText("choice is: " + selt);

			}
			public void onNothingSelected(AdapterView<?> parent)
			{
				final TextView spr = (TextView) findViewById(R.id.textview03);
				spr.setText("none selected");

			}
		});

		Button b1 = (Button)findViewById(R.id.btn1);
		b1.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v)
			{
				Toast.makeText(App1Activity.this, "Calling Flint", Toast.LENGTH_LONG).show();
				Log.i(DEBUG_TAG,"APP1 log - will call Flint");
				playmusic();
			}

		});


		Button b2 = (Button)findViewById(R.id.btn2);
		b2.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v)
			{
				Toast.makeText(App1Activity.this, "Showing Flint", Toast.LENGTH_LONG).show();
				Log.i(DEBUG_TAG,"APP1 log - will show Flint");
				playvideo();
			}

		});



	}
	public void onStop()
	{
		if (mp!=null)
		{
			mp.stop();
			mp.release();
			mp=null;
		}
		super.onStop();
	}

	
	public void playvideo()
	{

		try{
		VideoView vv = (VideoView) findViewById(R.id.vid1);
		MediaController mc = new MediaController(this);
		vv.setMediaController(mc);
//		File fl = new File("/mnt/sdcard/Download/flintmp4.mp4");
//		File fl = new File("c:\\agandroidNYU\\flintmp4.mp4");
//		Uri file = Uri.fromFile(fl);
//		Uri file = Uri.parse("http://www.youtube.com/watch?v=PIqz6JrSpUA");
//		Uri file = Uri.parse("http://ia600205.us.archive.org/13/items/israelbicepilp/israelbicep_512kb.mp4");
//		Uri file = Uri.parse("http://www.archive.org/download/Unexpect2001/Unexpect2001_512kb.mp4");
//		Uri file = Uri.parse("file:///android_asset/flintmp4.mp4");
//		Uri file = Uri.parse("file:///android_assets/flintmp4.mp4");
//		Uri file = Uri.parse("file:///c:/agandroidNYU/flintmp4.mp4");
//		Uri file = Uri.parse("file:///assets/flintmp4.mp4");
		Uri file = Uri.parse("file:///mnt/sdcard/Download/flintmp4.mp4");
		vv.setVideoURI(file);
//		vv.setVideoPath("app1/assets/flintmp4.mp4");
//		vv.setVideoPath("c:\\agandroidNYU\\flintmp4.mp4");
//		vv.setVideoPath("c:/agandroidNYU/flintmp4.mp4");
		vv.start();
		}
		catch( Exception e)
		{
			Log.e(DEBUG_TAG,"vid failure",e);
			e.printStackTrace();
		}

		
		}
	
	
	
	public void playmusic()
	{
		try{
			if (mp!=null)
			{
				mp.stop();
				mp.release();
				mp=null;
			}
			//        	Uri file = Uri.parse("http://www.perlgurl.org/podcast/archives" +
			//			"/podcasts/PerlgurlPromo.mp3");
			//        	Uri file = Uri.parse("file:///c:/agandroidNYU/flint.mp3");
			mp = MediaPlayer.create(this,R.raw.flintmp3);
			mp.start();
		}
		catch( Exception e)
		{
			Log.e(DEBUG_TAG,"mp failure",e);
			e.printStackTrace();
		}
	}   
}