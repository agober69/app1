package tabdemo.pkg1;

//import android.app.Activity;
import android.os.Bundle;
import android.app.TabActivity;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;
import android.util.Log;
//import com.example.android.apis.R;
/**
 * Example of using a tab content factory for the content via {@link TabHost.TabSpec#setContent(android.widget.TabHost.TabContentFactory)}
 *
 * It also demonstrates using an icon on one of the tabs via {@link TabHost.TabSpec#setIndicator(CharSequence, android.graphics.drawable.Drawable)}
 *
 */
public class TabdemoActivity extends TabActivity implements TabHost.TabContentFactory {

	static final String DEBUGTAG = "Tabdemo-debug";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        final TabHost tabHost = getTabHost();
        tabHost.addTab(tabHost.newTabSpec("tab1")
                .setIndicator("tab1", getResources().getDrawable(R.drawable.star_big_on))
                .setContent(this));
        tabHost.addTab(tabHost.newTabSpec("tab2")
                .setIndicator("tab2")
                .setContent(this));
        tabHost.addTab(tabHost.newTabSpec("tab3")
                .setIndicator("tab3")
                .setContent(this));
    }

    /** {@inheritDoc} */
    public View createTabContent(String tag) {
        final TextView tv = new TextView(this);
        tv.setText("Content for tabDemo with tag " + tag);
        Toast.makeText(getBaseContext(), "tabdemo toast", Toast.LENGTH_LONG).show();
        Log.d(DEBUGTAG,"in createTabContent");
        return tv;
    }
    
    @Override
    public void onStart()
    {
    	Log.d(DEBUGTAG,"onStart");
    	super.onStart();
    }

    @Override
    public void onResume()
    {
    	Log.d(DEBUGTAG,"onResume");
    	super.onResume();
    }
    @Override
    public void onPause()
    {
    	Log.d(DEBUGTAG,"onPause");
    	super.onPause();
    }
    @Override
    public void onStop()
    {
    	Log.d(DEBUGTAG,"onStop");
    	super.onStop();
    }
    @Override
    public void onDestroy()
    {
    	Log.d(DEBUGTAG,"onDestroy");
    	super.onDestroy();
    }
    @Override
    public void onRestart()
    {
    	Log.d(DEBUGTAG,"onRestart");
    	super.onRestart();
    }

}
