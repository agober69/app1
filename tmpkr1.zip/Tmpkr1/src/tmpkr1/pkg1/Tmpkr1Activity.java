package tmpkr1.pkg1;




import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.format.Time;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;


public class Tmpkr1Activity extends Activity {
	private Time time;
	private TextView textView;
	private TextView textView1;
	private TextView textView2;
	
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		final TimePicker timePicker = (TimePicker)findViewById(R.id.timePicker);
		
		timePicker.setIs24HourView(true);
		
		final Button button = (Button)findViewById(R.id.button);
		textView = (TextView)findViewById(R.id.textView);
		textView1 = (TextView)findViewById(R.id.textView1);
		textView2 = (TextView)findViewById(R.id.textView2);

		time = new Time("EST");	//Eastern Standard Time is 5 hours behind UT
		updateTextView(timePicker.getCurrentHour(), timePicker.getCurrentMinute());

		timePicker.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
			public void onTimeChanged(TimePicker view, int hour, int minute) {
				updateTextView(hour, minute);
			}
		});

		button.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				time.setToNow();	//Get the current time.
				timePicker.setCurrentHour(time.hour);	//calls onTimeChanged
				timePicker.setCurrentMinute(time.minute);
			}
		});
		
		
		final Handler handler = new Handler() {
			public void handleMessage(Message message) {
				textView.setText(String.format("%02d:%02d:%02d",
						//message.arg1, message.arg2)
						((hms)message.obj).hr,
						((hms)message.obj).min,
						((hms)message.obj).sec)
						);
			}
		};
	    
		final Handler handler1 = new Handler() {
			public void handleMessage(Message message) {
				textView1.setText(((s1)message.obj).s);
				textView.setText(((s1)message.obj).s);
						
			}
		};
	    
		final MyThread myThread = new MyThread(handler);
		myThread.start();
		final MyThread1 myThread1 = new MyThread1(handler1);
		myThread1.start();
		
		boolean b = false;
		b = textView2.post(new Run1());
		Toast.makeText(this,"post call result = "+b,Toast.LENGTH_LONG).show();
		System.out.println("post result = "+b);
	}

	private void updateTextView(int hour, int minute) {
		textView.setText(String.format("%02d:%02d",
				hour, minute));
	}
	
	
	
	class Run1 implements Runnable
	{
		String poststr;
		public void run()
		{
			/*****************************************/
			for (int i=0;i<25;i++) {
				try {
					//1000 milliseconds == 1 second
					Thread.sleep(500);
				} catch (InterruptedException e) {
					Log.e("ERROR", "Thread Interrupted--");
				}
				poststr="post#"+i;
				Tmpkr1Activity.this.textView2.setText(poststr);
				System.out.println("poststr="+poststr);
			}
			/*******************************************/
			
		}
	}

}



final class MyThread1 extends Thread {
	Handler handler;
	String str;

	MyThread1(Handler h) {
		handler = h;
		
	}
   
	public void run() {
		for (int i=0;i<1000;i++) {
			try {
				//1000 milliseconds == 1 second
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				Log.e("ERROR", "Thread Interrupted");
			}
			str="string#"+i;
			final Message message = handler.obtainMessage(); //Get an empty Message.
			message.obj = new s1(str);	//Fill it up.
			handler.sendMessage(message);	//Calls handleMessage, below.
		}
	}
}
class s1
{
	String s;
	s1(String s)
	{
		this.s=s;
	}
}

final class MyThread extends Thread {
	Handler handler;
	Time time;

	MyThread(Handler h) {
		handler = h;
		time = new Time("EST");
	}
   
	public void run() {
		for (;;) {
			try {
				//1000 milliseconds == 1 second
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				Log.e("ERROR", "Thread Interrupted");
			}

			time.setToNow();
			final Message message = handler.obtainMessage(); //Get an empty Message.
			//message.arg1 = time.minute;	//Fill it up.
			//message.arg2 = time.second;
			message.obj=new hms(time.hour,time.minute,time.second);
			handler.sendMessage(message);	//Calls handleMessage, below.
		}
	}
}

class hms
{
	int hr;
	int min;
	int sec;
	hms(int h, int m, int s)
	{
		hr=h;
		min=m;
		sec=s;
	}
}